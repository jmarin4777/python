from django import forms
from .models import Show

class addShow(forms.Form):
    title = forms.CharField(max_length=255, widget=forms.TextInput(
        attrs={
            'class': 'form-control',
            'id': 'title',
            'name': 'title',
        }
    ))
    network = forms.CharField(max_length=255, widget=forms.TextInput(
        attrs={
            'class': 'form-control ',
            'id': 'network',
            'name': 'network',
        }
    ))
    release_date = forms.CharField(max_length=255, widget=forms.TextInput(
        attrs={
            'class': 'form-control ',
            'id': 'release_date',
            'name': 'release_date',
        }
    ))
    desc = forms.CharField(max_length=255, widget=forms.Textarea(
        attrs={
            'class': 'form-control ',
            'id': 'desc',
            'name': 'desc',
            'rows': 3,
        }
    ))

# class editShow(forms.ModelForm):
#     class Meta:
#         model = Show
#         fields = ['title', 'network', 'release_date', 'desc']
#         widgets = {
#             'title': forms.TextInput(
#                 attrs={
#                     'class': 'form-control',
#                     'id': 'title',
#                     'name': 'title',
#                     'placeholder': "{{show.title}}",
#                 })
#         }
#     title = forms.CharField(max_length=255, widget=forms.TextInput(
#         attrs={
#             'class': 'form-control',
#             'id': 'title',
#             'name': 'title',
#             'placeholder': "{{show.title}}",
#         }
#     ))
#     network = forms.CharField(max_length=255, widget=forms.TextInput(
#         attrs={
#             'class': 'form-control ',
#             'id': 'network',
#             'name': 'network',
#             'placeholder': "{{show.network}}",
#         }
#     ))
#     release_date = forms.CharField(max_length=255, widget=forms.TextInput(
#         attrs={
#             'class': 'form-control ',
#             'id': 'release_date',
#             'name': 'release_date',
#             'placeholder': "{{show.release_date}}",
#         }
#     ))
#     desc = forms.CharField(max_length=255, widget=forms.Textarea(
#         attrs={
#             'class': 'form-control ',
#             'id': 'desc',
#             'name': 'desc',
#             'rows': 3,
#             'placeholder': "{{show.desc}}",
#         }
#     ))