from django.apps import AppConfig


class AppusersConfig(AppConfig):
    name = 'appUsers'
