from django.apps import AppConfig


class AppfirstdjangoConfig(AppConfig):
    name = 'appFirstDjango'
