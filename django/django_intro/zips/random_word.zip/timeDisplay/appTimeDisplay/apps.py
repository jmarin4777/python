from django.apps import AppConfig


class ApptimedisplayConfig(AppConfig):
    name = 'appTimeDisplay'
