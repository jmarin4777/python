from django.apps import AppConfig


class AppninjagoldConfig(AppConfig):
    name = 'appNinjaGold'
