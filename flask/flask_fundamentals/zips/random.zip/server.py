from flask import Flask, render_template, request, session, redirect
import random
app = Flask(__name__)
app.secret_key = "secret_key"

@app.route('/')
def root():
    if 'rand' not in session:
        session['count'] = 0
        session['box'] = ""
        session['rand'] = random.randint(1, 100)
    print(session['rand'])
    return render_template("random.html", rand = session['rand'], 
    box = session['box'], count = session['count'])

@app.route('/guess', methods = ["POST"])
def guess():
    guess = int(request.form['guess'])
    session['count'] += 1
    if guess>session['rand']:
        session['box'] = "high"
        return redirect('/')
    elif guess<session['rand']:
        session['box'] = "low"
        return redirect('/')
    else:
        session['box'] = "correct"
        return redirect('/')
    # return redirect('/')

@app.route('/correct', methods = ['POST'])
def correct():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)